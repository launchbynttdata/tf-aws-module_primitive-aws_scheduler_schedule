def handler(event, context):
    print(f"Lambda function invoked by {event}")
    return {}
